#ifndef FUNCOES_FORNECIDAS_H
#define FUNCOES_FORNECIDAS_H

// Função para exibir o conteúdo de um arquivo binário na tela
void binarioNaTela(char *nomeArquivoBinario);

// Função para ler strings delimitadas por aspas
void scan_quote_string(char *str);

#endif // FUNCOES_FORNECIDAS_H
